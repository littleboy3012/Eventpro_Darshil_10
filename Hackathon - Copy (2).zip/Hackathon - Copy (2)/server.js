const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();
const PORT = 5000;

app.use(cors()); // Allow cross-origin requests
app.use(bodyParser.json()); // Parse JSON body
app.use(express.static(path.join(__dirname, "Public"))); // Serve static files

const usersFile = path.join(__dirname, "users.json");
const jobsFile = path.join(__dirname, "jobs.json");
const applicationsFile = path.join(__dirname, "applications.json");

// 🟢 [1] User Signup
app.post("/signup", (req, res) => {
    const { name, email, password, isWorker, gender, age, contact } = req.body;
    let users = [];

    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }

    // Check if user already exists
    if (users.some(user => user.email === email)) {
        return res.status(400).json({ message: "User already exists" });
    }

    users.push({ 
        name, 
        email, 
        password,
        isWorker,
        gender,
        age,
        contact,
        createdAt: new Date().toISOString()
    });
    
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    res.status(201).json({ message: "Signup successful" });
});

// 🟢 [2] User Login
app.post("/login", (req, res) => {
    const { email, password } = req.body;
    let users = [];

    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }

    const user = users.find(user => user.email === email && user.password === password);

    if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
    }

    res.status(200).json({ 
        message: "Login successful", 
        user: {
            name: user.name,
            email: user.email,
            isWorker: user.isWorker,
            gender: user.gender
        }
    });
});

// 🟢 [3] Fetch Jobs (For Worker Dashboard)
app.get("/jobs", (req, res) => {
    if (!fs.existsSync(jobsFile)) {
        return res.status(200).json([]);
    }

    const jobs = JSON.parse(fs.readFileSync(jobsFile));
    res.json(jobs);
});

// 🟢 [4] Post Job (For Employers)
app.post("/post-job", (req, res) => {
    const { title, description, company, location, payment, duration, dressCode, ageRange, staffRequired, additionalRequirements } = req.body;
    let jobs = [];

    if (fs.existsSync(jobsFile)) {
        jobs = JSON.parse(fs.readFileSync(jobsFile));
    }

    const newJob = {
        id: Math.random().toString(36).substr(2, 9),
        title,
        description,
        company,
        location,
        payment,
        duration,
        dressCode,
        ageRange,
        staffRequired,
        additionalRequirements,
        status: 'Open',
        createdAt: new Date().toISOString()
    };

    jobs.push(newJob);
    fs.writeFileSync(jobsFile, JSON.stringify(jobs, null, 2));

    res.status(201).json({ message: "Job posted successfully", job: newJob });
});

// 🟢 [5] Apply for Job (For Workers)
app.post("/apply-job", (req, res) => {
    const { jobId, workerId } = req.body;
    let applications = [];

    if (fs.existsSync(applicationsFile)) {
        applications = JSON.parse(fs.readFileSync(applicationsFile));
    }

    // Check if already applied
    if (applications.some(app => app.jobId === jobId && app.workerId === workerId)) {
        return res.status(400).json({ message: "Already applied to this job" });
    }

    const newApplication = {
        id: Math.random().toString(36).substr(2, 9),
        jobId,
        workerId,
        status: 'Pending',
        appliedAt: new Date().toISOString()
    };

    applications.push(newApplication);
    fs.writeFileSync(applicationsFile, JSON.stringify(applications, null, 2));

    res.status(201).json({ message: "Application submitted successfully" });
});

// 🟢 [6] Get Worker's Applications
app.get("/worker/applications/:workerId", (req, res) => {
    const { workerId } = req.params;
    
    if (!fs.existsSync(applicationsFile)) {
        return res.status(200).json([]);
    }

    const applications = JSON.parse(fs.readFileSync(applicationsFile));
    const jobs = JSON.parse(fs.readFileSync(jobsFile));

    // Get worker's applications with job details
    const workerApplications = applications
        .filter(app => app.workerId === workerId)
        .map(app => {
            const job = jobs.find(j => j.id === app.jobId);
            return {
                ...app,
                jobDetails: job
            };
        });

    res.json(workerApplications);
});

// 🟢 [7] Worker Dashboard Data
app.get("/worker/dashboard/:workerId", (req, res) => {
    const { workerId } = req.params;
    
    // Get applications
    const applications = fs.existsSync(applicationsFile) ? 
        JSON.parse(fs.readFileSync(applicationsFile)) : [];
    
    // Get jobs
    const jobs = fs.existsSync(jobsFile) ? 
        JSON.parse(fs.readFileSync(jobsFile)) : [];

    // Calculate worker-specific stats
    const workerApplications = applications.filter(app => app.workerId === workerId);
    const stats = {
        totalApplications: workerApplications.length,
        pendingApplications: workerApplications.filter(app => app.status === 'Pending').length,
        acceptedApplications: workerApplications.filter(app => app.status === 'Accepted').length,
        availableJobs: jobs.filter(job => job.status === 'Open').length,
        recentApplications: workerApplications
            .sort((a, b) => new Date(b.appliedAt) - new Date(a.appliedAt))
            .slice(0, 5)
    };

    res.json(stats);
});

// 🟢 [8] Serve HTML Files
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "Public", "index.html"));
});

// Start Server
app.listen(PORT, () => {
    console.log(`✅ Server running at http://localhost:${PORT}`);
});
